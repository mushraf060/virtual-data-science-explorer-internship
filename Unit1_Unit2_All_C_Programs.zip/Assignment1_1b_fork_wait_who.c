#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <utmp.h>
#include <string.h>

void show_users()
{
    int fd;
    struct utmp entry;

    fd = open("/var/run/utmp", O_RDONLY);

    if (fd == -1)
    {
        perror("open utmp");
        return;
    }

    while (read(fd, &entry, sizeof(entry)) == sizeof(entry))
    {
        if (entry.ut_type == USER_PROCESS)
        {
            printf("User: %s\n", entry.ut_user);
        }
    }

    close(fd);
}

int main()
{
    pid_t pid = fork();

    if (pid == -1)
    {
        perror("fork");
        exit(1);
    }

    if (pid == 0)
    {
        printf("Child PID: %d\n", getpid());
        printf("Parent PID: %d\n", getppid());

        pid_t grandchild = fork();

        if (grandchild == -1)
        {
            perror("fork");
            exit(1);
        }

        if (grandchild == 0)
        {
            printf("Grandchild PID: %d\n", getpid());
            show_users();
            exit(0);
        }
        else
        {
            wait(NULL);
        }
    }
    else
    {
        wait(NULL);
        printf("Parent PID: %d\n", getpid());
        printf("Parent: Child completed.\n");
    }

    return 0;
}
