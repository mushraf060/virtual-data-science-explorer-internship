#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

int pipefd[2];

void handler(int sig)
{
    int n;
    pid_t pid;

    printf("\nSIGINT received. Enter N: ");
    scanf("%d", &n);

    if (pipe(pipefd) == -1)
    {
        perror("pipe");
        return;
    }

    pid = fork();

    if (pid == -1)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        int a = 0, b = 1, next;
        pid_t child_pid = getpid();

        close(pipefd[0]);

        write(pipefd[1], &child_pid, sizeof(child_pid));

        for (int i = 0; i < n; i++)
        {
            write(pipefd[1], &a, sizeof(a));

            next = a + b;
            a = b;
            b = next;
        }

        write(pipefd[1], &sig, sizeof(sig));

        close(pipefd[1]);
        exit(0);
    }
    else
    {
        pid_t child_pid;
        int value;
        int signal_id;

        close(pipefd[1]);

        read(pipefd[0], &child_pid, sizeof(child_pid));
        printf("Child PID: %d\n", child_pid);

        printf("Fibonacci terms: ");

        for (int i = 0; i < n; i++)
        {
            read(pipefd[0], &value, sizeof(value));
            printf("%d ", value);
        }

        printf("\n");

        read(pipefd[0], &signal_id, sizeof(signal_id));
        printf("Signal ID: %d\n", signal_id);

        close(pipefd[0]);
        wait(NULL);
    }
}

int main()
{
    signal(SIGINT, handler);

    printf("Program running. Press Ctrl+C.\n");

    while (1)
    {
        pause();
    }

    return 0;
}
