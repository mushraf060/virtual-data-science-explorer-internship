#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define KEY 1234

struct message
{
    long msg_type;
    char msg_text[200];
};

int main()
{
    int msgid;
    struct message msg;

    msgid = msgget(KEY, 0666 | IPC_CREAT);

    if (msgid == -1)
    {
        perror("msgget");
        exit(1);
    }

    fprintf(stderr, "Message Queue ID: %d\n", msgid);

    printf("Server waiting for message...\n");

    msgrcv(msgid, &msg, sizeof(msg.msg_text), 1, 0);

    printf("Message received: %s\n", msg.msg_text);

    msg.msg_type = 2;
    strcpy(msg.msg_text, "ACKNOWLEDGEMENT FROM SERVER");

    msgsnd(msgid, &msg, strlen(msg.msg_text) + 1, 0);

    printf("Acknowledgement sent.\n");

    msgctl(msgid, IPC_RMID, NULL);

    return 0;
}
