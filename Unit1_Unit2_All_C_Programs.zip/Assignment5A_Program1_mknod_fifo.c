#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define FIFO_NAME "/tmp/myfifo"

int main()
{
    int fd;
    char buffer[200];

    if (mknod(FIFO_NAME, S_IFIFO | 0666, 0) == -1)
    {
        if (access(FIFO_NAME, F_OK) == -1)
        {
            perror("mknod");
            exit(1);
        }
    }

    fd = open(FIFO_NAME, O_RDWR);

    if (fd == -1)
    {
        perror("open");
        exit(1);
    }

    printf("Program1 is running...\n");
    printf("Waiting for message from Program2...\n");

    memset(buffer, 0, sizeof(buffer));
    read(fd, buffer, sizeof(buffer));

    printf("Message received: %s\n", buffer);

    strcpy(buffer, "ACKNOWLEDGEMENT FROM PROGRAM1");

    write(fd, buffer, strlen(buffer) + 1);

    printf("Acknowledgement sent.\n");

    close(fd);

    return 0;
}
