#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *thread_function(void *arg)
{
    printf("Thread is running.\n");
    printf("Thread ID: %lu\n", (unsigned long)pthread_self());

    pthread_exit(NULL);
}

int main()
{
    pthread_t thread;

    if (pthread_create(&thread, NULL, thread_function, NULL) != 0)
    {
        perror("pthread_create");
        exit(1);
    }

    pthread_join(thread, NULL);

    printf("Thread completed.\n");

    return 0;
}
