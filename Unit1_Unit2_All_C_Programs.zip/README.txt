UNIT 1 TO UNIT 2 - ALL C PROGRAMS

Assignment 1:
1a fork, child and grandchild
1b fork, wait and utmp user information
1c fork and execv

Assignment 2:
2a signal handler
2b kill
2c pthread_create/pthread_exit

Assignment 3:
signal + pipe + fork + Fibonacci

Assignment 4:
read + fcntl file locking
Requires data.txt in the same folder.

Assignment 5:
5A named FIFO using mknod
5B System V Message Queue

These programs are intended for Linux/WSL because they use POSIX/Linux system calls.
