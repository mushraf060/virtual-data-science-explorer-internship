#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>

int main()
{
    int pid;
    int signal_number;

    printf("Enter process ID: ");
    scanf("%d", &pid);

    printf("Enter signal number: ");
    scanf("%d", &signal_number);

    if (kill(pid, signal_number) == 0)
    {
        printf("Signal sent successfully.\n");
    }
    else
    {
        perror("kill");
    }

    return 0;
}
