#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define FIFO_NAME "/tmp/myfifo"

int main()
{
    int fd;
    char buffer[200];

    printf("Enter message: ");
    fgets(buffer, sizeof(buffer), stdin);
    buffer[strcspn(buffer, "\n")] = '\0';

    fd = open(FIFO_NAME, O_RDWR);

    if (fd == -1)
    {
        perror("open");
        exit(1);
    }

    write(fd, buffer, strlen(buffer) + 1);

    printf("Message sent: %s\n", buffer);

    sleep(1);

    memset(buffer, 0, sizeof(buffer));
    read(fd, buffer, sizeof(buffer));

    printf("Acknowledgement received: %s\n", buffer);

    close(fd);

    return 0;
}
