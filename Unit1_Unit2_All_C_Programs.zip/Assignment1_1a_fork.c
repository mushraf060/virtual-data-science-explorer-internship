#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    pid_t pid;

    pid = fork();

    if (pid == -1)
    {
        perror("fork");
        exit(1);
    }

    if (pid == 0)
    {
        printf("Child PID: %d\n", getpid());
        printf("Parent PID: %d\n", getppid());

        pid_t grandchild = fork();

        if (grandchild == -1)
        {
            perror("fork");
            exit(1);
        }

        if (grandchild == 0)
        {
            printf("Grandchild PID: %d\n", getpid());
            printf("Roll Number: CSB25204\n");
            exit(0);
        }
        else
        {
            wait(NULL);
        }

        exit(1);
    }
    else
    {
        printf("Parent PID: %d\n", getpid());
        wait(NULL);
        printf("Parent: Child completed.\n");
    }

    return 0;
}
