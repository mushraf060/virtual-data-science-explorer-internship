#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

void handler(int sig)
{
    pid_t pid = fork();

    if (pid == -1)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        printf("Signal %d received. Child PID: %d\n", sig, getpid());
        exit(0);
    }
    else
    {
        printf("Signal %d received. Parent PID: %d\n", sig, getpid());
        wait(NULL);
    }
}

int main()
{
    signal(SIGINT, handler);

    printf("Press Ctrl+C to generate SIGINT.\n");
    pause();

    return 0;
}
