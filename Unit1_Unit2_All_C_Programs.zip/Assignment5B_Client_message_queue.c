#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define KEY 1234

struct message
{
    long msg_type;
    char msg_text[200];
};

int main()
{
    int msgid;
    struct message msg;

    msgid = msgget(KEY, 0666);

    if (msgid == -1)
    {
        perror("msgget");
        exit(1);
    }

    printf("Enter message: ");
    fgets(msg.msg_text, sizeof(msg.msg_text), stdin);
    msg.msg_text[strcspn(msg.msg_text, "\n")] = '\0';

    msg.msg_type = 1;

    msgsnd(msgid, &msg, strlen(msg.msg_text) + 1, 0);

    printf("Message sent: %s\n", msg.msg_text);

    msgrcv(msgid, &msg, sizeof(msg.msg_text), 2, 0);

    printf("Acknowledgement received: %s\n", msg.msg_text);

    return 0;
}
