#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    int fd;
    char buffer[200];
    struct flock lock;

    fd = open("data.txt", O_RDONLY);

    if (fd == -1)
    {
        perror("open");
        exit(1);
    }

    lock.l_type = F_RDLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = 0;
    lock.l_len = 0;
    lock.l_pid = getpid();

    printf("Process %d waiting for lock...\n", getpid());

    if (fcntl(fd, F_SETLKW, &lock) == -1)
    {
        perror("fcntl");
        close(fd);
        exit(1);
    }

    printf("Process %d got the lock.\n", getpid());

    int n = read(fd, buffer, sizeof(buffer) - 1);

    if (n == -1)
    {
        perror("read");
    }
    else
    {
        buffer[n] = '\0';
        printf("File content:\n%s\n", buffer);
    }

    printf("Press Enter to release the lock...\n");
    getchar();

    lock.l_type = F_UNLCK;

    if (fcntl(fd, F_SETLK, &lock) == -1)
    {
        perror("fcntl");
        close(fd);
        exit(1);
    }

    printf("Process %d released the lock.\n", getpid());

    close(fd);

    return 0;
}
